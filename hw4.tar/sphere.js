
class sphere{
    // Your code goes here:
    // in hit(r, rec):
    //      return false if discriminant is less than 0
    //      otherwise, update rec and then return true 







}