
class ray{
   // Your code goes here:
   
   

   

}