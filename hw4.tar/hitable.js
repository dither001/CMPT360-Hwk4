
class hit_record {
    get t() { return this.t_val; };
    set t(val){ this.t_val = val; };

    // Your code goes here:
    // Follow the example above to write getter() and setter() for p and normal.




}




